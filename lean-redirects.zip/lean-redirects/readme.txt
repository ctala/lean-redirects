=== Lean Redirects ===
Contributors: ctala
Tags: redirect, 301, 302, seo, lightweight
Requires at least: 5.6
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The redirect plugin that does nothing else. One indexed DB query. Zero JavaScript. No bloat.

== Description ==

Lean Redirects is the simplest way to manage 301, 302, and 307 redirects in WordPress.

**The problem with redirects inside SEO plugins:** Most SEO plugins (Yoast, Rank Math, AIOSEO) include redirects as a feature. Convenient, until you want to switch. Your redirects are trapped inside the plugin — that's vendor lock-in. Lean Redirects keeps your redirects independent, in their own table, completely decoupled from your SEO stack.

**The problem with dedicated redirect plugins:** They come loaded with features you don't need — 404 logging, analytics dashboards, regex engines, import wizards for 10 different formats, and upsells to premium versions. All of that adds overhead to every single page load on your site.

**Lean Redirects takes a different approach: do one thing, do it well, and get out of the way.**

This plugin is for people who care about what runs on every page load. One function, one indexed query, zero bloat.

= How it works =

* Stores redirects in a dedicated database table with an indexed column
* Processes redirects with a single indexed query on `template_redirect`
* No deserialization of large option blobs
* No custom post type queries
* No JavaScript loaded on the frontend
* No external API calls
* No tracking, no analytics, no phone-home

= Features =

* **301, 302, 307 redirects** — permanent, temporary, and strict temporary
* **Hit counter** — see which redirects are actually being used
* **Search** — find redirects quickly as your list grows
* **Pagination** — handles hundreds of redirects without slowing down the admin
* **Notes** — add context to each redirect (migration batch, ticket number, etc.)
* **Toggle on/off** — disable a redirect without deleting it
* **CSV Import/Export** — bulk manage redirects with simple `from,to,code` format
* **REST API** — programmatically manage redirects (`GET/POST/DELETE /wp-json/lean-redirects/v1/redirects`)
* **Settings link** — quick access from the Plugins page
* **Clean uninstall** — removes the table when you delete the plugin

= What it doesn't do (on purpose) =

* ❌ No 404 error logging (use a dedicated tool if you need this)
* ❌ No regex matching (keeps the query simple and fast)
* ❌ No wildcard matching
* ❌ No redirect chains detection
* ❌ No premium version or upsells
* ❌ No JavaScript frameworks
* ❌ No custom CSS files
* ❌ No external dependencies

= How does it compare? =

LOC = Lines of Code. Fewer lines mean less complexity, fewer potential bugs, and an easier security audit.

* Redirection (2M+ installs): ~15,000 LOC — 404 logging, analytics, regex, 10 import formats
* Safe Redirect Manager: ~3,000 LOC — regex, wildcards, hook-heavy
* Simple 301 Redirects: ~500 LOC — converted to BetterLinks upsell
* **Lean Redirects: ~475 LOC** — just redirects

= Performance =

On a site with 1,000 redirects, Lean Redirects adds approximately **0.5ms** to each page load. Compare this to plugins that deserialize large option arrays (~5-15ms) or query custom post types (~2-8ms).

The secret is simple: one `SELECT` on an indexed `VARCHAR(191)` column. That's it.

== Installation ==

1. Upload the `lean-redirects` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu
3. Go to **Settings → Redirects** to manage your redirects

== Frequently Asked Questions ==

= Does this work with custom post types and pages? =

Yes. It intercepts any request at the `template_redirect` hook, before WordPress renders anything. It works with any URL path.

= Can I redirect to external URLs? =

Yes. Put the full URL (including `https://`) in the "To" field.

= What happens if I deactivate the plugin? =

Your redirects stay in the database. Reactivate and they're back.

= What happens if I delete the plugin? =

The database table is removed. Export your redirects first if you want to keep them.

= Is it compatible with caching plugins? =

Yes. Since redirects happen at the PHP level before any output, they work with all major caching plugins. For best performance with page caching, ensure your cache plugin doesn't cache redirected URLs.

= Can I use the REST API? =

Yes. Requires authentication with a user that has `manage_options` capability.

* `GET /wp-json/lean-redirects/v1/redirects` — list all redirects
* `POST /wp-json/lean-redirects/v1/redirects` — add a redirect (`from`, `to`, `code`, `note`)
* `DELETE /wp-json/lean-redirects/v1/redirects` — delete a redirect (`from`)

== Screenshots ==

1. Main admin screen — manage all redirects with hit counter, search, toggle, and pagination

== Changelog ==

= 1.0.1 =
* Fix: Escape output in admin header (absint for active/total counts)
* Fix: Prefix all template variables to pass Plugin Check naming conventions
* Tested up to WordPress 6.9

= 1.0.0 =
* Initial release
* 301/302/307 redirects with indexed database table
* Admin UI under Settings → Redirects
* Search, pagination, toggle, delete
* CSV import/export
* REST API (GET/POST/DELETE)
* Hit counter
* Notes field
* Clean uninstall

== Upgrade Notice ==

= 1.0.0 =
Initial release.

== About the Author ==

Built by [Cristian Tala](https://cristiantala.com) — entrepreneur, angel investor, and efficiency nerd based in Chile.

* 🌐 [cristiantala.com](https://cristiantala.com) — Blog about tech, startups, and automation
* 💼 [LinkedIn](https://www.linkedin.com/in/ctala/)
* 🐦 [X / Twitter](https://x.com/naitus)
* 📸 [Instagram](https://www.instagram.com/cristiantalasanchez/)
* 🎙️ [YouTube](https://www.youtube.com/@ecosistemastartup)
* 🛠️ [More tools](https://cristiantala.com/herramientas/) — Free utilities for WordPress

Found a bug? Have a feature request? [Open an issue on GitHub](https://github.com/ctala/lean-redirects/issues).
